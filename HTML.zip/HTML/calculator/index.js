document.addEventListener("DOMContentLoaded", function () {
  let result = document.querySelector(".result");
  let clearButton = document.querySelector("#clear");
  let equalsButton = document.querySelector("#equals");

  clearButton.addEventListener("click", function () {
    result.textContent = "0";
  });

  equalsButton.addEventListener("click", function () {
    try {
      result.textContent = eval(result.textContent);
    } catch (error) {
      result.textContent = "Error";
    }
  });

  document.querySelectorAll(".btn-secondary").forEach(function (button) {
    button.addEventListener("click", function () {
      if (result.textContent === "0" || result.textContent === "Error") {
        result.textContent = button.textContent;
      } else {
        result.textContent += button.textContent;
      }
    });
  });
});
