document
.getElementById("surveyForm")
.addEventListener("submit", function (e) {
  e.preventDefault();
  const firstName = document.getElementById("firstName").value;
  const lastName = document.getElementById("lastName").value;
  const dob = document.getElementById("dob").value;
  const country = document.getElementById("country").value;
  const gender = document.querySelector('input[name="gender"]:checked');
  const profession = document.getElementById("profession").value;
  const email = document.getElementById("email").value;
  const mobile = document.getElementById("mobile").value;

  // Regular expressions for validation
  const nameRegex = /^[A-Za-z\s]+$/;
  const dobRegex = /^\d{4}-\d{2}-\d{2}$/;
  const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
  const mobileRegex = /^\d{10}$/;

  const firstNameValidation = nameRegex.test(firstName);
  const lastNameValidation = nameRegex.test(lastName);
  const dobValidation = dobRegex.test(dob);
  const emailValidation = emailRegex.test(email);
  const mobileValidation = mobileRegex.test(mobile);

  if (
    firstNameValidation &&
    lastNameValidation &&
    dobValidation &&
    emailValidation &&
    mobileValidation
  ) {
    alert("Form Submitted Successfully");
    this.reset();
  } else {
    alert("Please fill responses correctly");
  }
});