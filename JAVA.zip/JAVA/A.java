import java.util.Arrays;
import java.util.Random;

class A
{
	public static void shuffle(int arr[])
	{
		for (int i = arr.length - 1; i >= 1; i--)
		{
            Random rand = new Random();
            int j = rand.nextInt(i + 1);
            swap_elements(arr, i, j);
		}
	}
        private static void swap_elements(int[] arr, int i, int j) {
		int temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
	}
	public static void main (String[] args)
	{
		int[] arr = { 1, 2, 3, 4, 5, 6, 7 };
        System.out.println("Given Array: "+Arrays.toString(arr));
		shuffle(arr);
		System.out.println("Shuffled Array: "+Arrays.toString(arr));
	}
}
