import java.util.Scanner;

class C {
    public static void pangram(String s){
        s= s.toLowerCase();
        boolean isPangram = true;
        for(char ch = 'a'; ch <='z'; ch++){
            if(!s.contains(String.valueOf(ch))){
                isPangram = false;
                break;
            }
        }
        if(isPangram){
            System.out.println("Pangram");
        }
        else{
            System.out.println("Not a Pangram");
        }
    }
    public static void main(String args[])
    {
        try (Scanner ob = new Scanner(System.in)) {
            System.out.println("Enter the string to be tested");
            String str = ob.nextLine();
            pangram(str);
        }
    
    }
}
