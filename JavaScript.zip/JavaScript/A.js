const str= "This is a sunny day";
const wordArr = str.split('  ');
for(let i = 0;i<wordArr.length;i++){
    let word = wordArr[i];
    let temp = "";
    for(let j=word.length-1; j >= 0;j--){
        temp = temp + word[j];
    }
    wordArr[i]= temp;
} 
const reversedSentence = wordArr.join('  ');
console.log(reversedSentence);