function sortDesc(arr){
    const l = arr.length;
    for( let i=0;i<l-1;i++){
        for(let j=0;j< l-1-i;j++){
            if(arr[j]<arr[j+1]){
                const temp = arr[j];
                arr[j]= arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
    return arr;
}
const unsortedArr = [5,65,89,2,34,78,54];
const sortedArr = sortDesc(unsortedArr);
console.log(sortedArr);